"""Assemble fixed email copy around generated openings without model calls."""
import argparse
import json
from pathlib import Path


def assemble(row, variants, index):
    result = dict(row)
    opening = str(row.get('opening') or '').strip()
    if not opening:
        return {**result, 'status': 'needs_hook'}, index
    if not variants:
        return {**result, 'status': 'company_copy_pending'}, index
    variant_index = (index // 2) % len(variants)
    variant = variants[variant_index]
    name = str(row.get('name') or 'there').strip() or 'there'
    cta = variant.get('cta') or 'You got 12 minutes this week for a quick call?'
    email = f"Hey {name},\n\n{opening}\n\n{variant['body']}\n\n{cta}"
    if '\u2014' in email:
        return {**result, 'status': 'revise_em_dash'}, index
    return {**result, 'variant': variant_index + 1, 'email': email, 'status': 'draft'}, index + 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--client', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--start', type=int, default=0)
    parser.add_argument('--copy', type=Path, default=Path(__file__).resolve().parents[1] / 'references/company-copy.json')
    args = parser.parse_args()
    if args.start < 0 or args.input.resolve() == args.output.resolve():
        parser.error('Use a nonnegative start and different input/output paths')
    copy = json.loads(args.copy.read_text(encoding='utf-8'))
    if args.client not in copy:
        parser.error('Client missing from copy config')
    index, rows, pending = args.start, 0, 0
    with args.input.open(encoding='utf-8') as source, args.output.open('w', encoding='utf-8') as target:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError('Row must be an object')
                result, index = assemble(row, copy[args.client], index)
            except (ValueError, TypeError) as error:
                result = {'line': line_number, 'status': 'invalid_row', 'error': str(error)}
            target.write(json.dumps(result, ensure_ascii=False) + '\n')
            rows += 1
            pending += result['status'] != 'draft'
    print(json.dumps({'rows': rows, 'drafted': rows - pending, 'pending': pending, 'next_start': index}))


if __name__ == '__main__':
    main()
