---
name: growency-email-writer
description: Quickly turn supplied Growency research briefs or compact lead rows into short cold emails for Posting Machine, Kairos Health and Infratex, singly or in large batches. Use one personal detail, approved company copy and a 12-minute ask. Perform no prospect research or qualification.
---

# Growency Email Writer

## Fast drafting

Treat this as writing and assembly from supplied evidence. Do not browse links, run the research skill, retrieve writing samples, inspect company relationships or check B2B status, fit, dates, followers or customer maturity. Those belong upstream. Do not exclude prospects or add background-check warnings. Use the supplied examples as the voice. Load only this file and the relevant client copy once per run; do not load unrelated workflows unless higher-priority instructions require them.

Read each brief once. Pick one usable detail, write one opening, assemble and check completeness briefly. Produce no analysis, alternatives, citations, scoring or research recaps unless requested. Do not run another research pass. Accept 100+ briefs without individual clarification. Default to one email per brief; do not multiply 100 briefs into 2,000 unless explicitly requested.

For large batches, generate only openings and identifiers, then use scripts/assemble.py to insert fixed copy. Process manageable chunks and continue through the whole supplied batch without asking between chunks. Keep input order and IDs. Save the full result as a file instead of repeating thousands of emails in chat. Do not claim batching guarantees a particular usage charge or speed: personalized output still consumes tokens.

## Small inputs

Accept full research briefs unchanged, or a compact row:

`id | first_name | company | one research detail`

Set client once for the batch. Optional fields: subject, scaffold, company-copy override, CTA. Do not require links, followers, qualification or extra research. Use the first relevant supplied detail when several are present. Use `Hey there,` when no first name is supplied. If there is no usable hook, mark that row `needs_hook` and continue with the rest; do not invent one.

## Structure and style

1. `Hey [first_name],`
2. One short personal paragraph, normally 15-30 words, maximum 35. Use one research hook and at most one brief reaction or suggestion. Do not stack angles. For Moonshot, an everyday-uses hook must not acquire an extra privacy angle.
3. One approved company paragraph copied unchanged.
4. Exactly one supplied call ask, or `You got 12 minutes this week for a quick call?` if none was supplied.

Aim for 55-85 words overall where the fixed copy permits. Use casual language, contractions and short sentences. Never use em dashes, emojis, generic flattery or an unsolicited sign-off. Add a short subject for individual chat drafts; omit bulk subjects unless requested.

Keep facts within the supplied research. Do not invent quotes, metrics, problems, referral paths or personal experiences. `Saw your post about...` is fine when its contents are supplied. Do not claim to have loved, tested, watched or used something unless the sender supplied that experience. Phrase content angles as suggestions. Do not recheck approved proof points during drafting.

## Natural wording

Use the concrete examples below before abstract instructions like "humanize". Write like a brief note to one person. Keep the sender's casual voice without turning every opening into praise. Natural wording is a writing goal, not a guarantee about AI detection or replies.

- Prefer one concrete observation and one short reaction, or a single direct question. An observation alone is enough. Do not force a content suggestion into every opening.
- Use ordinary words: "use", "help", "write", "calls". Cut any sentence that adds neither a specific detail nor a useful reaction.
- Avoid stock filler: "I hope this finds you well", "I came across", "I was impressed by", "your innovative approach", "really caught my attention", "in today's fast-paced world", "game-changing", "unlock your potential", "take it to the next level", "perfect fit" and "seamlessly".
- Do not default to "there's a whole series in that", "deserves a post of its own" or "must be difficult" for every lead. Use those scaffold clauses only when they fit the supplied hook. Treat the Kairos workload lines as tentative possibilities, never known pain.
- Allow contractions and sentence fragments when natural. Do not manufacture typos, add slang or insert filler words to disguise generation. Do not replace every short word with a synonym to create variety.
- Keep "CRAZY" available because the user selected it, but reserve it for an enthusiastic product reaction; do not attach it automatically to every company. Do not exaggerate an ordinary update into a major achievement.
- Vary sentence length and opening structure across a batch using the supplied hooks. Avoid three consecutive generic praise openings. Do not rewrite approved company paragraphs or CTAs for variety.
- Before assembly, check the opening once: one grounded hook, one angle, no empty praise, no em dash. Fix obvious filler immediately, without generating alternatives or running a second model pass. Do not research during this check.

Examples of the target voice, not additional prospect evidence:

- Simulithic: `Saw Satyam's post about onboarding your waitlist companies. Have you thought about sharing the testing lessons as you go?`
- Moonshot: `Moonshot is CRAZY. Have you thought about posting a few examples of how people could use Samantha day to day?`
- Tsenta: `Saw creator partnerships are your biggest acquisition channel. Thought that was smart for a job-search product.`

Avoid: `Your innovative approach to AI companionship really caught my attention. There is enormous potential to turn your unique journey into compelling thought leadership.`

See references/writing-research.md only when revising the skill or when the user asks for sources. Do not read it for each email or batch. Preserve the user's fixed 12-minute ask even when external advice recommends a different CTA.

## Selected opening scaffolds

Adapt minimally to the hook. Keep one angle and the word limit; optional clauses are alternatives, not a list to fill completely.

Posting Machine:

- `[Company] is CRAZY. [One short reaction or content suggestion].` Use `Loved your content too (I actually came from [person]'s post where they said "[quote]")` only when that experience and quote are supplied; omit competing angles.
- `Saw [person]'s post about [company]. Thought [specific detail] was actually really smart, especially for [customer type].` Use `Loved` or `checked it out` only when the sender supplies that experience.
- `"[Exact short quote]". [That's genius / that's so smart / I'm gonna live by that forever].` Alternatively use `The bit about [same idea] deserves a post of its own.` Never invent quotes.
- `Crazy launch with [feature]. Have you thought about creating content around [one angle] and building in public?`

Kairos Health:

- `Saw you're hiring a [receptionist / patient coordinator]. I imagine keeping patient calls and bookings organised takes a fair bit of work.`
- `Saw you're hiring a new dentist. I imagine there's a fair bit to coordinate as you start booking patients into their schedule.`
- `Congrats on the [location] opening. I imagine keeping patient enquiries and bookings organised takes some coordination.`
- `Had a look at your offices in [locations]. I imagine getting patient calls and bookings to the right office can get pretty busy.`

Infratex:

- `You describe [company] as "[exact slogan]". With [document workflow], I'm sure you've got loads of documents to process.`
- `[Company] helps [customer] [task]. I imagine managing the [document type] behind that can get pretty difficult.`

Keep Infratex's service explanation in the company paragraph. Use `We usually find...` only when supplied as the sender's actual experience.

## Company copy and rotation

Read references/company-copy.json once for the requested client. Prefer later user-supplied replacements. Rotate company paragraphs in pairs, A, A, B, B, C, C, then repeat, independently of scaffold choice. Maintain a per-client counter across chunks. If copy is missing, return openings with `company_copy_pending`; do not invent pitches or block other clients. Preserve the earlier Kairos distinction between dental production and attributable revenue without re-investigating it during drafting.

For bulk assembly, write JSONL rows containing `id`, `name`, `company`, `opening`; optionally `subject`. Run:

`python3 scripts/assemble.py openings.jsonl --client postingmachine --output emails.jsonl --start 0`

Pass the returned `next_start` for the next chunk. Assemble different clients separately and restore source order by ID. Pass `--copy` for replacement company-copy JSON. Return all rows, including incomplete ones with a short status. Do not send emails or create external email drafts.
